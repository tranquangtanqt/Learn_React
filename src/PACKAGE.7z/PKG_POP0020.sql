create or replace NONEDITIONABLE PACKAGE PKG_POP0020 IS

  -- Author  : TANTQ
  -- Created : 2022/07/12
  -- Purpose : PKG_POP0020
    
  PROCEDURE   POP0020(
    I$CO_CD IN VARCHAR2
  );
  
END PKG_POP0020;