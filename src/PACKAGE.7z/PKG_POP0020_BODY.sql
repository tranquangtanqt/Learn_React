create or replace NONEDITIONABLE PACKAGE BODY PKG_POP0020 IS
/*
||-----------------------------------------------------------------------------
||�����v���V�[�W���錾
||-----------------------------------------------------------------------------
*/
PROCEDURE INSERT_POP_INST (
         POP_INST_rec           IN  MSTA_POP_INST_ALL%rowtype
);

PROCEDURE UPDATE_POP_INST_RESET_QTY (
         POP_INST_rec           IN  MSTA_POP_INST_ALL%rowtype
);

PROCEDURE UPDATE_POP_INST_QTY (
         POP_INST_rec           IN  MSTA_POP_INST_ALL%rowtype
);

FUNCTION CONVERT_DATE_STRING_YYYYMMDDHHMMSS  (
    date_value         IN  DATE
) RETURN VARCHAR2;

FUNCTION CONVERT_DATE_STRING_YYYYMMDD  (
    date_value         IN  DATE
) RETURN VARCHAR2;

FUNCTION CONVERT_DATE_STRING_HHMM  (
    date_value         IN  DATE
) RETURN VARCHAR2;

PROCEDURE INSERT_YIELD_ACT_RECV_FILE_WK (
    YIELD_ACT_RECV_WK_rec        IN  MSTA_YIELD_ACT_RECV_FILE_WK_ALL%rowtype
);


PROCEDURE INSERT_OPER_ACT_RECV_FILE_WK (
    OPER_ACT_RECV_WK_rec         IN    MSTA_OPER_ACT_RECV_FILE_WK_ALL%rowtype
);

 PROCEDURE INSERT_WK_ACT_RECV_FILE_WK (
    WK_ACT_RECV_WK_rec           IN    MSTA_WK_ACT_RECV_FILE_WK_ALL%rowtype
);

FUNCTION SQL_SUM_STOP_SEC(
    ROW_ID IN VARCHAR2
) RETURN VARCHAR2;

FUNCTION SQL_UNPIVOT_STOP_SEC(
    ROW_ID IN VARCHAR2
) RETURN VARCHAR2;

FUNCTION SQL_MAN_HOUR_MANAGEMENT_OPTION(
    ROW_ID IN VARCHAR2
) RETURN VARCHAR2;

FUNCTION SQL_MAN_HOUR_MANAGEMENT_CODE(
    ROW_ID IN VARCHAR2
) RETURN VARCHAR2;

FUNCTION GET_LOTNO(
    NUM_PTN_CD IN VARCHAR2,
    CO_CD IN VARCHAR2
) RETURN VARCHAR2;
/*
||-----------------------------------------------------------------------------
||
||-----------------------------------------------------------------------------
*/
    PROCEDURE POP0020 (
        I$CO_CD IN VARCHAR2
    )IS
        PRAGMA autonomous_transaction;
        sSQL                            VARCHAR2(12048);
        sSQLsub                         VARCHAR2(12048);
        sSQLsum                         VARCHAR2(12048);
        sSQLunpivot                     VARCHAR2(12048);

        V1_rec                          MSVTA_POP_ACT_FILE_WK%rowtype;
        CURSOR CURSOR_V1 IS
            SELECT row_id, equipment_cd, inst_no, inst_ts, output_typ FROM MSVTA_POP_ACT_FILE_WK;

        TYPE POP0020_A IS REF CURSOR;
        CURSOR_POP0020_A               POP0020_A;
        POP_STR_ACT_FILE_WK_rec         MSTA_POP_STR_ACT_FILE_WK_ALL%rowtype;
        
        TYPE POP0020_B IS REF CURSOR;
        CURSOR_POP0020_B               POP0020_B;

        TYPE POP0020_C IS REF CURSOR;
        CURSOR_POP0020_C               POP0020_C;
        POP_PRCD_ACT_FILE_WK_rec         MSTA_POP_PRCD_ACT_FILE_WK_ALL%rowtype;

        POP_INST_rec         MSTA_POP_INST_ALL%rowtype;

        TYPE POP0020_D IS REF CURSOR;
        CURSOR_POP0020_D                POP0020_D;
        YIELD_ACT_RECV_WK_rec           MSTA_YIELD_ACT_RECV_FILE_WK_ALL%rowtype;

        TYPE POP0020_E IS REF CURSOR;
        CURSOR_POP0020_E                POP0020_E;
        OPER_ACT_RECV_WK_rec       MSTA_OPER_ACT_RECV_FILE_WK_ALL%rowtype;

        TYPE POP0020_F IS REF CURSOR;
        CURSOR_POP0020_F                POP0020_F;

        TYPE POP0020_G IS REF CURSOR;
        CURSOR_POP0020_G                POP0020_G;

        TYPE POP0020_H IS REF CURSOR;
        CURSOR_POP0020_H                POP0020_H;
        WK_ACT_RECV_WK_rec              MSTA_WK_ACT_RECV_FILE_WK_ALL%rowtype;

        TYPE POP0020_I IS REF CURSOR;
        CURSOR_POP0020_I                POP0020_I;

        TYPE POP0020_J IS REF CURSOR;
        CURSOR_POP0020_J                POP0020_J;
        POP_PRCD_ACT_rec         MSTA_POP_PRCD_ACT_FILE_WK_ALL%rowtype;

        TYPE POP0020_K IS REF CURSOR;
        CURSOR_POP0020_K                POP0020_K;
        TYPE POP0020_K_SUM IS REF CURSOR;
        CURSOR_POP0020_K_SUM                POP0020_K_SUM;

        TYPE POP0020_L IS REF CURSOR;
        CURSOR_POP0020_L                POP0020_L;
        TYPE POP0020_L_SUB IS REF CURSOR;
        CURSOR_POP0020_L_SUB                POP0020_L_SUB;
        row_id_m_n                      VARCHAR2(2048);
        column_name_m_n                 VARCHAR2(2048);
        n_value                         VARCHAR2(2);
        m_value                         VARCHAR2(2);
        stop_sec_m_n                    NUMBER;

        TYPE POP0020_M IS REF CURSOR;
        CURSOR_POP0020_M                POP0020_M;
        TYPE POP0020_M_SUB IS REF CURSOR;
        CURSOR_POP0020_M_SUB            POP0020_M_SUB;
        row_id_man_hour                 VARCHAR2(2048);
        wk_cost                         VARCHAR2(5);
        val_num                             NUMBER;

        TYPE POP0020_N IS REF CURSOR;
        CURSOR_POP0020_N                POP0020_N;
        TYPE POP0020_N_SUB IS REF CURSOR;
        CURSOR_POP0020_N_SUB            POP0020_N_SUB;
        code                            VARCHAR2(5);
        val_str                         VARCHAR2(5);

        TYPE POP0020_O IS REF CURSOR;
        CURSOR_POP0020_O                POP0020_O;

        TYPE POP0020_P IS REF CURSOR;
        CURSOR_POP0020_P                POP0020_P;
        TYPE POP0020_P_SUB IS REF CURSOR;
        CURSOR_POP0020_P_SUB                POP0020_P_SUB;
        no_ptn_cd               VARCHAR2(10);
        lot_no_cd               VARCHAR2(100);

        row_id                  VARCHAR2(2048);
        count_record            NUMBER;
        file_name               DATE;
        date_and_time           DATE;
        prcd_order              VARCHAR2(100);
        seq_data_no             VARCHAR2(15);
        ext_oper_act_no         VARCHAR2(17);

        inst_st                 DATE;
        inst_end                DATE;
        sum_stop_sec            NUMBER;

    BEGIN

        FCPA_CONTEXT.SET_CO_CD(I$CO_CD);

        FOR V1_rec IN CURSOR_V1 LOOP
--            DBMS_OUTPUT.put_line(V1_rec.ROW_ID);

            -- 1. POP�����w�}�󋵃e�[�u����}������B
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   ROWID, T1.INST_NO ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_STR_ACT_FILE_WK_ALL  T1 ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T1.INST_NO ';

            OPEN CURSOR_POP0020_A FOR sSQL;

            LOOP
                FETCH CURSOR_POP0020_A INTO 
                row_id
                , POP_STR_ACT_FILE_WK_rec.INST_NO;
                EXIT WHEN CURSOR_POP0020_A%NOTFOUND;

                SELECT COUNT(*) INTO count_record
                FROM MSTA_POP_INST_ALL
                WHERE MFG_INST_NO = POP_STR_ACT_FILE_WK_rec.INST_NO;
                IF count_record = 0 THEN

                    sSQLsub := '';
                    sSQLsub := sSQLsub || ' SELECT ';
                    sSQLsub := sSQLsub || '   T2.LOT_NO_PTN_CD ';
                    sSQLsub := sSQLsub || ' FROM ';
                    sSQLsub := sSQLsub || '   MST_MFG_INST M1  ';
                    sSQLsub := sSQLsub || '   INNER JOIN MST_ITM_MFG_INST M2  ';
                    sSQLsub := sSQLsub || '     ON M1.ITM_MFG_INST_NO = M2.ITM_MFG_INST_NO  ';
                    sSQLsub := sSQLsub || '   INNER JOIN MAM_ITM T2  ';
                    sSQLsub := sSQLsub || '     ON T2.ITM_CD = M2.ITM_CD  ';
                    sSQLsub := sSQLsub || '     AND T2.ITM_SUB1 = M2.ITM_SUB1  ';
                    sSQLsub := sSQLsub || '     AND T2.ITM_SUB2 = M2.ITM_SUB2  ';
                    sSQLsub := sSQLsub || '     AND T2.ITM_SUB3 = M2.ITM_SUB3  ';
                    sSQLsub := sSQLsub || ' WHERE ';
                    sSQLsub := sSQLsub || '   M1.MFG_INST_NO = ' || '''' || POP_STR_ACT_FILE_WK_rec.INST_NO || '''';
                    
                    OPEN CURSOR_POP0020_B FOR sSQLsub;
                    LOOP
                        FETCH CURSOR_POP0020_B INTO 
                            no_ptn_cd;   
                        EXIT WHEN CURSOR_POP0020_B%NOTFOUND;
                        IF no_ptn_cd IS NOT NULL THEN
                            lot_no_cd := GET_LOTNO(no_ptn_cd, I$CO_CD);
                            POP_INST_rec.LOT_NO := lot_no_cd; --TODO: �V�K���b�gNO���ԁiMCF�W�����b�g���ԃv���V�[�W�����g�p�j
                            EXIT;
                        END IF;
                    END LOOP;
                    CLOSE CURSOR_POP0020_B;

                    POP_INST_rec.MFG_INST_NO := POP_STR_ACT_FILE_WK_rec.INST_NO;
                    POP_INST_rec.CO_CD := I$CO_CD;
                    POP_INST_rec.TRD_UNIT_MFG_QTY := 0;
                    POP_INST_rec.EXT_OPER_ACT_NO := MAC_STR.NULL_VAL;
                    INSERT_POP_INST(POP_INST_rec);
                ELSE 
                    POP_INST_rec.MFG_INST_NO := POP_STR_ACT_FILE_WK_rec.INST_NO;
                    POP_INST_rec.EXT_OPER_ACT_NO := MAC_STR.NULL_VAL;
                    UPDATE_POP_INST_RESET_QTY(POP_INST_rec);
                END IF;

            END LOOP;

            CLOSE CURSOR_POP0020_A;

            -- 1.2. POP���Y���уt�@�C���e�[�u���Ɋ�Â��APOP�����w�}�󋵃e�[�u�����X�V����B
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   ROWID, T1.INST_NO, T1.TRD_UNIT_MFG_QTY ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL  T1 ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T1.INST_NO ';
            OPEN CURSOR_POP0020_C FOR sSQL;

            LOOP
                FETCH CURSOR_POP0020_C INTO 
                row_id
                , POP_PRCD_ACT_FILE_WK_rec.INST_NO
                , POP_PRCD_ACT_FILE_WK_rec.TRD_UNIT_MFG_QTY;
                EXIT WHEN CURSOR_POP0020_C%NOTFOUND;

                SELECT COUNT(*) INTO count_record
                FROM MSTA_POP_INST_ALL
                WHERE MFG_INST_NO = POP_PRCD_ACT_FILE_WK_rec.INST_NO;

                IF count_record <> 0 THEN
                    POP_INST_rec.MFG_INST_NO := POP_PRCD_ACT_FILE_WK_rec.INST_NO;
                    POP_INST_rec.TRD_UNIT_MFG_QTY := POP_PRCD_ACT_FILE_WK_rec.TRD_UNIT_MFG_QTY;
                    UPDATE_POP_INST_QTY(POP_INST_rec);
                END IF;
            END LOOP;

            CLOSE CURSOR_POP0020_C;

            --2. �f�[�^���擾���A�o�������ю�M�t�@�C�� (����)�e�[�u����}������ (IF�t�@�C�����o�͎d�l (1))
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   WK1.FILE_NAME ';
            sSQL := sSQL || '   , T3.YIELD_SCHD_NO ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , T1.LOT_NO ';
            sSQL := sSQL || '   , WK1.INST_TS ';
            sSQL := sSQL || '   , WK1.INST_NO ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_STR_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MST_OPER_INST_ALL T2  ';
            sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
            sSQL := sSQL || '   INNER JOIN MST_YIELD_SCHD_ALL T3  ';
            sSQL := sSQL || '     ON T3.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T3.OPER_INST_NO = T2.OPER_INST_NO  ';
            sSQL := sSQL || '     AND T3.YIELD_TYP = ''1''  ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   WK1.ACHIEVEMENT_CLASS = ''4''  ';
            sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T1.MFG_INST_NO ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , T3.YIELD_SCHD_NO ';

            OPEN CURSOR_POP0020_D FOR sSQL;
            LOOP
                FETCH CURSOR_POP0020_D INTO 
                file_name
                , YIELD_ACT_RECV_WK_rec.YIELD_SCHD_NO
                , YIELD_ACT_RECV_WK_rec.OPER_INST_NO
                , YIELD_ACT_RECV_WK_rec.LOT_NO
                , date_and_time
                , prcd_order;
                EXIT WHEN CURSOR_POP0020_D%NOTFOUND;

                -- �f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                YIELD_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE .nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                YIELD_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                --������CD = 'F1020'
                 YIELD_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1020';
                --"���M�����R�[�h�쐬���� = POP������уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)"
                YIELD_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = 1'
                YIELD_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                --�o�����\��NO = T3.�o�����\��NO
                --�H���w�}NO = T2.�H���w�}NO
                --����P�ʐ��� = 0
                YIELD_ACT_RECV_WK_rec.TRD_UNIT_QTY := 0;
                --�o�����敪 = '1'
                YIELD_ACT_RECV_WK_rec.YIELD_TYP := '1';
                --���b�gNO = T1.���b�gNO
                --"���ѓ� = WK1.���� (yyyy/MM/dd)
                YIELD_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(date_and_time);
                --"���ю��� = WK1.���� (hh:mm)
                YIELD_ACT_RECV_WK_rec.ACT_HM := CONVERT_DATE_STRING_HHMM(date_and_time);
                --�O���H������NO = "KT" + {�f�[�^�sNO}
                YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := 'KT' || YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�O���o��������NO = {�f�[�^�sNO}
                YIELD_ACT_RECV_WK_rec.EXT_YIELD_ACT_NO := YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�o�͎�� = '1'
                YIELD_ACT_RECV_WK_rec.OUTPUT_TYP := '1';

                INSERT_YIELD_ACT_RECV_FILE_WK(YIELD_ACT_RECV_WK_rec);

                UPDATE MSTA_POP_INST_ALL SET EXT_OPER_ACT_NO = YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO
                WHERE MFG_INST_NO = prcd_order;

            END LOOP;
            CLOSE CURSOR_POP0020_D;

            --3. �f�[�^���擾���A�H�����ю�M�t�@�C�� (������)�e�[�u����}������
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   WK1.FILE_NAME ';
            sSQL := sSQL || '   , T1.EXT_OPER_ACT_NO  ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_STR_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   WK1.ACHIEVEMENT_CLASS = ''15'' ';
            sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            OPEN CURSOR_POP0020_E FOR sSQL;

            LOOP
                FETCH CURSOR_POP0020_E INTO 
                file_name
                , OPER_ACT_RECV_WK_rec.EXT_OPER_ACT_NO;
                EXIT WHEN CURSOR_POP0020_E%NOTFOUND;

                --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                OPER_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_OPER_ACT_RECV_FILE .nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                OPER_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_OPER_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                --������CD = 'F1040'
                OPER_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1040';
                --"���M�����R�[�h�쐬���� = POP������уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                OPER_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = '3'
                OPER_ACT_RECV_WK_rec.DATA_CRUD_TYP := '3';
                --�O���H������NO = T1.����O���H������NO
                 --�o�͎�� = '2'
                OPER_ACT_RECV_WK_rec.OUTPUT_TYP := '2';

                INSERT_OPER_ACT_RECV_FILE_WK(OPER_ACT_RECV_WK_rec);
            END LOOP;
            CLOSE CURSOR_POP0020_E;

            --4. POP0020_F�J�[�\�����쐬�A�f�[�^���擾���� (IF�t�@�C�����o�͎d�l (3) �@�s�Ǖi�o��������)
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   WK1.FILE_NAME ';
            sSQL := sSQL || '   , T3.YIELD_SCHD_NO ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , WK1.AMOUNT_OF_SCRAP / M1.UNIT_WT ';
            sSQL := sSQL || '   , M2.CHAR1 ';
            sSQL := sSQL || '   , WK1.INST_TS  ';
            sSQL := sSQL || '   , WK1.INST_NO  ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_SCRAP_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
            sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
            sSQL := sSQL || '   INNER JOIN MST_YIELD_SCHD T3  ';
            sSQL := sSQL || '     ON T3.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T3.OPER_INST_NO = T2.OPER_INST_NO  ';
            sSQL := sSQL || '     AND T3.YIELD_TYP = ''1''  ';
            sSQL := sSQL || '   INNER JOIN MST_ITM_MFG_INST T4  ';
            sSQL := sSQL || '     ON T4.ITM_MFG_INST_NO = T2.ITM_MFG_INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MAM_ITM M1  ';
            sSQL := sSQL || '     ON M1.ITM_CD = T4.ITM_CD  ';
            sSQL := sSQL || '     AND M1.ITM_SUB1 = T4.ITM_SUB1  ';
            sSQL := sSQL || '     AND M1.ITM_SUB2 = T4.ITM_SUB2  ';
            sSQL := sSQL || '     AND M1.ITM_SUB3 = T4.ITM_SUB3  ';
            sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M2  ';
            sSQL := sSQL || '     ON M2.GP_GRP_CD = ''H0009''  ';
            sSQL := sSQL || '     AND M2.KEY1 = WK1.REASON_CD  ';
            sSQL := sSQL || '     AND M2.KEY2 = WK1.REASON_D_CD ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   WK1.INST_NO, T2.OPER_INST_NO, T3.YIELD_SCHD_NO ';
            OPEN CURSOR_POP0020_F FOR sSQL;

            YIELD_ACT_RECV_WK_rec := NULL;
            seq_data_no := '';
            ext_oper_act_no := '';

            LOOP
                FETCH CURSOR_POP0020_F INTO 
                file_name
                , YIELD_ACT_RECV_WK_rec.YIELD_SCHD_NO
                , YIELD_ACT_RECV_WK_rec.OPER_INST_NO
                , YIELD_ACT_RECV_WK_rec.TRD_UNIT_QTY
                , YIELD_ACT_RECV_WK_rec.LOT_NO
                , date_and_time
                , YIELD_ACT_RECV_WK_rec.MFG_INST_NO;
                EXIT WHEN CURSOR_POP0020_F%NOTFOUND;

                --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j�H���w�}NO�������ꍇ�A1�񂾂�SEQ�𐶐�����
                YIELD_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE .nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                YIELD_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                --������CD = 'F1020'
                YIELD_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1020';
                --"���M�����R�[�h�쐬���� = POP�X�N���b�v���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                YIELD_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = '1'
                YIELD_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                --�o�����\��NO = T3.�o�����\��NO
                --�H���w�}NO = T2.�H���w�}NO
                --����P�ʐ��� = WK1.�X�N���b�v�� ��  M1.�d�ʁi��{�d�ʁj(���L�X�N���b�v�ʂ͒P�ʁFkg �ł��邽�߁A�{�����Z�����l���Z�b�g���{�� �� �X�N���b�v�� �� �i�ڃ}�X�^.�d�ʁi��{�d�ʁj)
                --�o�����敪 = '2'
                YIELD_ACT_RECV_WK_rec.YIELD_TYP := '2';
                --���b�gNO = M2.������P
                --"���ѓ� = WK1.���� (yyyy/MM/dd)
                YIELD_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(date_and_time);
                --"���ю��� = WK1.���� (hh:mm)
                YIELD_ACT_RECV_WK_rec.ACT_HM := CONVERT_DATE_STRING_HHMM(date_and_time);
                --�O���H������NO = "KT" + {�f�[�^�sNO}
                YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := 'KT' || YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�O���o��������NO = {�f�[�^�sNO}
                YIELD_ACT_RECV_WK_rec.EXT_YIELD_ACT_NO := YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�o�͎�� = '3'
                YIELD_ACT_RECV_WK_rec.OUTPUT_TYP := '3';
                INSERT_YIELD_ACT_RECV_FILE_WK(YIELD_ACT_RECV_WK_rec);

                ext_oper_act_no := YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO; --**(1)
                seq_data_no := YIELD_ACT_RECV_WK_rec.DATA_NO;
            END LOOP;

            CLOSE CURSOR_POP0020_F;

            --5. ���Y�i�o�������� (IF�t�@�C�����o�͎d�l (3) �A���Y�i�o��������)
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   WK1.FILE_NAME ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , M2.CHAR2 ';
            sSQL := sSQL || '   , WK1.AMOUNT_OF_SCRAP ';
            sSQL := sSQL || '   , M1.UNIT_CD ';
            sSQL := sSQL || '   , T3.STRG_LOC_CD ';
            sSQL := sSQL || '   , T3.STRG_STR_LN_CD ';
            sSQL := sSQL || '   , WK1.INST_TS  ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_SCRAP_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
            sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
            sSQL := sSQL || '   INNER JOIN MST_ITM_MFG_INST T3  ';
            sSQL := sSQL || '     ON T3.ITM_MFG_INST_NO = T2.ITM_MFG_INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MAM_ITM M1  ';
            sSQL := sSQL || '     ON M1.ITM_CD = T3.ITM_CD  ';
            sSQL := sSQL || '     AND M1.ITM_SUB1 = T3.ITM_SUB1  ';
            sSQL := sSQL || '     AND M1.ITM_SUB2 = T3.ITM_SUB2  ';
            sSQL := sSQL || '     AND M1.ITM_SUB3 = T3.ITM_SUB3  ';
            sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M2  ';
            sSQL := sSQL || '     ON M2.GP_GRP_CD = ''H0008'' ';
            sSQL := sSQL || '     AND M2.KEY1 = ''2''  ';
            sSQL := sSQL || '     AND M2.KEY2 = CONCAT(''S'', WK1.REASON_CD) ';
            sSQL := sSQL || '     AND M2.KEY3 = WK1.SCRAP_HANDLING_CD ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T2.MFG_INST_NO, T2.OPER_INST_NO ';

            OPEN CURSOR_POP0020_G FOR sSQL;
            YIELD_ACT_RECV_WK_rec := NULL;

            LOOP
                FETCH CURSOR_POP0020_G INTO 
                file_name
                , YIELD_ACT_RECV_WK_rec.OPER_INST_NO
                , YIELD_ACT_RECV_WK_rec.ITM_CD
                , YIELD_ACT_RECV_WK_rec.TRD_UNIT_QTY
                , YIELD_ACT_RECV_WK_rec.TRD_UNIT_CD
                , YIELD_ACT_RECV_WK_rec.STRG_LOC_CD
                , YIELD_ACT_RECV_WK_rec.STRG_STR_LN_CD
                , date_and_time;
                EXIT WHEN CURSOR_POP0020_G%NOTFOUND;

                --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                YIELD_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE.nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ��� 
                YIELD_ACT_RECV_WK_rec.DATA_NO := seq_data_no;     --�y�s�Ǖi�z��SEQ���g�p
                --������CD = 'F1020'
                YIELD_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1020';
                --"���M�����R�[�h�쐬���� = POP�X�N���b�v���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                YIELD_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = '1'
                YIELD_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                --�H���w�}�m�n = T2.�H���w�}�m�n
                --�i�ڃR�[�h =  M2.����2
                --����P�ʐ��� = WK1.�X�N���b�v��
                --����P�ʂb�c = M1.�P�ʂb�c
                --�o�����敪 = '3'
                YIELD_ACT_RECV_WK_rec.YIELD_TYP := '3';
                --�i�[�ꏊCD = T3.�i�[��ꏊ�R�[�h
                --�i�[�I�E���C��CD = T3.�i�[�I�E���C���R�[�h
                --"���ѓ� = WK1.���� (yyyy/MM/dd)
                YIELD_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(date_and_time);
                --"���ю��� = WK1.���� (hh:mm)
                 YIELD_ACT_RECV_WK_rec.ACT_HM := CONVERT_DATE_STRING_HHMM(date_and_time);
                --�O���H������NO = **(1)�ɕۑ����ꂽ�Y���l���擾����B
                YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := ext_oper_act_no;
                --�O���o�������тm�n = {�f�[�^�sNO}
                YIELD_ACT_RECV_WK_rec.EXT_YIELD_ACT_NO := YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�o�͎�� = '3'
                YIELD_ACT_RECV_WK_rec.OUTPUT_TYP := '3';

                INSERT_YIELD_ACT_RECV_FILE_WK(YIELD_ACT_RECV_WK_rec);
            END LOOP;

            CLOSE CURSOR_POP0020_G;

            --6. �H������ (IF�t�@�C�����o�͎d�l (3) �B�H������)
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   WK1.FILE_NAME ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , M2.CHAR1 ';
            sSQL := sSQL || '   , M3.CHAR1 ';
            sSQL := sSQL || '   , WK1.AMOUNT_OF_SCRAP ';
            sSQL := sSQL || '   , WK1.INST_TS ';
            sSQL := sSQL || '   , DECODE(WK1.SERVICE_SYSTEM, 1, ''A'', 2, ''B'', ''C'') ';
            sSQL := sSQL || '   , SUBSTR(WK1.WK_USR_CD, 2, 4) ';
            sSQL := sSQL || '   , M1.DPT_CD  ';
            sSQL := sSQL || '   , T2.MFG_INST_NO  ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_SCRAP_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
            sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
            sSQL := sSQL || '   INNER JOIN MAM_USR_ACL M1  ';
            sSQL := sSQL || '     ON M1.USR_CD = SUBSTR(WK1.WK_USR_CD, 2, 4)  ';
            sSQL := sSQL || '     AND M1.ST_DT <= SYSDATE  ';
            sSQL := sSQL || '     AND M1.END_DT >= SYSDATE  ';
            sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M2  ';
            sSQL := sSQL || '     ON M2.GP_GRP_CD = ''H0008''  ';
            sSQL := sSQL || '     AND M2.KEY1 = ''2''  ';
            sSQL := sSQL || '     AND M2.KEY2 = CONCAT(''S'', WK1.REASON_CD)  ';
            sSQL := sSQL || '     AND M2.KEY3 = WK1.SCRAP_HANDLING_CD  ';
            sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M3  ';
            sSQL := sSQL || '     ON M3.GP_GRP_CD = ''H0009''  ';
            sSQL := sSQL || '     AND M3.KEY1 = CONCAT(''S'', WK1.REASON_CD)  ';
            sSQL := sSQL || '     AND M3.KEY2 = WK1.REASON_D_CD ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T2.MFG_INST_NO, T2.OPER_INST_NO, M1.USR_CD ';

            OPEN CURSOR_POP0020_H FOR sSQL;
            WK_ACT_RECV_WK_rec := NULL;

            LOOP
                FETCH CURSOR_POP0020_H INTO 
                file_name
                , WK_ACT_RECV_WK_rec.OPER_INST_NO
                , WK_ACT_RECV_WK_rec.WK_COST_CD
                , WK_ACT_RECV_WK_rec.WK_RSN_CD
                , WK_ACT_RECV_WK_rec.WK_COST
                , date_and_time
                , WK_ACT_RECV_WK_rec.WK_DAY_CD
                , WK_ACT_RECV_WK_rec.WK_USR_CD
                , WK_ACT_RECV_WK_rec.WK_USR_DPT_CD
                , WK_ACT_RECV_WK_rec.MFG_INST_NO;
                EXIT WHEN CURSOR_POP0020_H%NOTFOUND;

                --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                WK_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_ACT_RECV_FILE.nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                WK_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                --������CD = 'F1070'
                WK_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1070';
                --���M�����R�[�h�쐬���� = POP�X�N���b�v���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                WK_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = '1'
                WK_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                --�H���w�}NO = T2.�H���w�}NO
                --�H���Ǘ�CD = M2.�����P
                --�H�����RCD = M3.�����P
                --�H�� = WK1.�X�N���b�v��
                --"�v��� = WK1.���� (yyyy/MM/dd)
                WK_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(date_and_time);
                --�Ζ����CD = DECODE (WK1.�Ζ��̌n, 1, 'A', 2, 'B', 'C' )
                --��Ǝ�CD = SUBSTR(WK1.��Ǝ҃R�[�h, 2, 4)
                --��Ǝҕ���CD = M1.�啔��R�[�h
                --�O���H������NO =  **(1)�ɕۑ����ꂽ�Y���l���擾����B
                WK_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := ext_oper_act_no;
                --�o�͎�� = '3'
                WK_ACT_RECV_WK_rec.OUTPUT_TYP := '3';

                INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);
            END LOOP;

            CLOSE CURSOR_POP0020_H;

            --7. �Ǖi�o�������� (IF�t�@�C�����o�͎d�l (4) �@�Ǖi�o��������)
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   WK1.FILE_NAME ';
            sSQL := sSQL || '   , T3.YIELD_SCHD_NO ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , WK1.TRD_UNIT_MFG_QTY ';
            sSQL := sSQL || '   , T1.LOT_NO ';
            sSQL := sSQL || '   , WK1.INST_END ';
            sSQL := sSQL || '   , CASE  ';
            sSQL := sSQL || '     WHEN WK1.PRCD_RECORD_STT = ''5''  ';
            sSQL := sSQL || '     AND T4.BASE_UNIT_INST_QTY > T1.TRD_UNIT_MFG_QTY  ';
            sSQL := sSQL || '       THEN ''1''  ';
            sSQL := sSQL || '     ELSE NULL  ';
            sSQL := sSQL || '     END  ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
            sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
            sSQL := sSQL || '   INNER JOIN MST_YIELD_SCHD T3  ';
            sSQL := sSQL || '     ON T3.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '     AND T3.OPER_INST_NO = T2.OPER_INST_NO  ';
            sSQL := sSQL || '     AND T3.YIELD_TYP = ''1''  ';
            sSQL := sSQL || '   INNER JOIN MST_MFG_INST T4  ';
            sSQL := sSQL || '     ON T4.MFG_INST_NO = T1.MFG_INST_NO ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T2.MFG_INST_NO, T2.OPER_INST_NO,T3.YIELD_SCHD_NO ';

            OPEN CURSOR_POP0020_I FOR sSQL;
            YIELD_ACT_RECV_WK_rec := NULL;

            LOOP
                FETCH CURSOR_POP0020_I INTO 
                file_name
                , YIELD_ACT_RECV_WK_rec.YIELD_SCHD_NO
                , YIELD_ACT_RECV_WK_rec.OPER_INST_NO
                , YIELD_ACT_RECV_WK_rec.TRD_UNIT_QTY
                , YIELD_ACT_RECV_WK_rec.LOT_NO
                , date_and_time
                , YIELD_ACT_RECV_WK_rec.ABORT_FLG;
                EXIT WHEN CURSOR_POP0020_I%NOTFOUND;

                --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                YIELD_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE.nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                YIELD_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_YIELD_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                --������CD = 'F1020'
                YIELD_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1020';
                --���M�����R�[�h�쐬���� = POP���Y���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                YIELD_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = '1'
                YIELD_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                --�o�����\��NO = T3.�o�����\��NO
                --�H���w�}NO = T2.�H���w�}NO
                --����P�ʐ��� = WK1.�Ǖi�o������
                --�o�����敪 = '1'
                YIELD_ACT_RECV_WK_rec.YIELD_TYP := '1';
                --���b�gNO = T1.���b�gNO
                --���ѓ� = WK1.���� WK1.�I������ (yyyy/MM/dd)
                YIELD_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(date_and_time);
                --"���ю��� = WK1.���� WK1.�I������ (hh:mm)
                YIELD_ACT_RECV_WK_rec.ACT_HM := CONVERT_DATE_STRING_HHMM(date_and_time);
                --�Ő�FLG = WK1.���Y���я�� = "5"(����)�A�y��T4.��P�ʐ����w�}���� (�w�}��) > T1.�݌v�o�������̏ꍇ�u�P�v�Ɛݒ肷��B�t���̏ꍇ�ݒ肵�Ȃ��B
                --�O���H������NO = "KT" + {�f�[�^�sNO}  **(3)�O���H������NO�̒l��ۑ�����z����g�p���� (**(4)�Ŏg�p�����)
                YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := 'KT' || YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�O���o��������NO = {�f�[�^�sNO}
                YIELD_ACT_RECV_WK_rec.EXT_YIELD_ACT_NO := YIELD_ACT_RECV_WK_rec.DATA_LNO;
                --�o�͎�� = '4'
                YIELD_ACT_RECV_WK_rec.OUTPUT_TYP := '4';

                INSERT_YIELD_ACT_RECV_FILE_WK(YIELD_ACT_RECV_WK_rec);
                ext_oper_act_no := YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO;
            END LOOP;
            CLOSE CURSOR_POP0020_I;

            --8. �H������ (IF�t�@�C�����o�͎d�l (4) �A�H������)
            --  �f�[�^���擾���A�H�����ю�M�t�@�C�� (���Y����)��}������
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '    * ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   ROWID LIKE ' || '''' || V1_rec.row_id || '''';

            OPEN CURSOR_POP0020_J FOR sSQL;
            POP_PRCD_ACT_rec := NULL;

            LOOP
                FETCH CURSOR_POP0020_J INTO POP_PRCD_ACT_rec;
                EXIT WHEN CURSOR_POP0020_J%NOTFOUND;

                --8.2.1. �H���Ǘ�CD = �ғ�����(TX001)�ɉ����郌�R�[�h���o�͂���
                sSQL := '';
                sSQL := sSQL || ' SELECT ';
                sSQL := sSQL || '   FILE_NAME ';
                sSQL := sSQL || '   , T2.OPER_INST_NO ';
                sSQL := sSQL || '   , WK1.INST_ST ';
                sSQL := sSQL || '   , WK1.INST_END ';
                sSQL := sSQL || '   , DECODE(WK1.SERVICE_SYSTEM, 1, ''A'', 2, ''B'', ''C'') ';
                sSQL := sSQL || '   , SUBSTR(WK1.WK_USR_CD, 2, 4) ';
                sSQL := sSQL || '   , M1.DPT_CD  ';
                sSQL := sSQL || ' FROM ';
                sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
                sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
                sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
                sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
                sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
                sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
                sSQL := sSQL || '   INNER JOIN MAM_USR_ACL M1  ';
                sSQL := sSQL || '     ON M1.USR_CD = SUBSTR(WK1.WK_USR_CD, 2, 4)  ';
                sSQL := sSQL || '     AND M1.ST_DT <= SYSDATE  ';
                sSQL := sSQL || '     AND M1.END_DT >= SYSDATE  ';
                sSQL := sSQL || ' WHERE ';
                sSQL := sSQL || '   WK1.INST_NO = ' || '''' ||POP_PRCD_ACT_rec.INST_NO || '''';
                sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
                sSQL := sSQL || ' ORDER BY ';
                sSQL := sSQL || '   T2.MFG_INST_NO ';
                sSQL := sSQL || '   , T2.OPER_INST_NO ';
                sSQL := sSQL || '   , M1.USR_CD ';

                OPEN CURSOR_POP0020_K FOR sSQL;
                WK_ACT_RECV_WK_rec := NULL;

                LOOP
                    FETCH CURSOR_POP0020_K INTO 
                        file_name
                        , WK_ACT_RECV_WK_rec.OPER_INST_NO
                        , inst_st
                        , inst_end
                        , WK_ACT_RECV_WK_rec.WK_DAY_CD
                        , WK_ACT_RECV_WK_rec.WK_USR_CD
                        , WK_ACT_RECV_WK_rec.WK_USR_DPT_CD;   
                    EXIT WHEN CURSOR_POP0020_K%NOTFOUND;

                    -- �f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                    WK_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_ACT_RECV_FILE.nextval, 'FM0000000'));
                    --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                    WK_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                    --������CD = 'F1070'
                    WK_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1070';
                    --���M�����R�[�h�쐬���� = POP���Y���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                    WK_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                    --�f�[�^�X�V�敪 = '1'
                    WK_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                    --�H���w�}NO = T2.�H���w�}NO
                    --�H���Ǘ�CD = "TX001" (�ғ�����)
                    WK_ACT_RECV_WK_rec.WK_COST_CD := 'TX001';
                    --�H�� = �ҏW�Ȃ�
                    --�������l = �ҏW�Ȃ�
                    --�����H���v�Z�X�V����F = '1'
                    WK_ACT_RECV_WK_rec.WK_COST_CALC_UPD_FLG := '1';
                    --�Ζ����CD = DECODE (WK1.�Ζ��̌n, 1, 'A', 2, 'B', 'C' )
                    --��Ǝ�CD = SUBSTR(WK1.��Ǝ҃R�[�h, 2, 4)
                    --��Ǝҕ���CD = M1.�啔��R�[�h
                    --�O���H������NO = **(3)�ɕۑ����ꂽ�Y���l���擾����B
                    WK_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := ext_oper_act_no;
                     --�o�͎�� = '4'
                    WK_ACT_RECV_WK_rec.OUTPUT_TYP := '4';
                    --"���f���� = SUM(WK1.�ғ���~����_N_M)
                    --���m�F1�`10�A�l�F1�`10
                    --���J�n�`�I���œ��t���܂����Ń��R�[�h���������ꍇ�A
                    --�@�@ ���f���Ԃ͍ŏ��̃��R�[�h�ɂ̂݃Z�b�g����B"
                    sSQLsum := '';
                    sSQLsum := SQL_SUM_STOP_SEC(V1_rec.row_id);
                    OPEN CURSOR_POP0020_K_SUM FOR sSQLsum;
                    sum_stop_sec := 0;
                    LOOP
                        FETCH CURSOR_POP0020_K_SUM INTO sum_stop_sec;
                        EXIT WHEN CURSOR_POP0020_K_SUM%NOTFOUND;
                    END LOOP;
                    CLOSE CURSOR_POP0020_K_SUM;

                    WK_ACT_RECV_WK_rec.BRK_PD := sum_stop_sec;

                    --�v���, ���莞��, �I������
                    --�H���Ǘ�CD = "�ғ�����" �̏ꍇ�̂݁A
                    --POP���Y���уt�@�C��.�J�n�����A�I���������ݒ�
                    --���J�n�`�I���œ��t���܂����ꍇ�A0:00�Ń��R�[�h�𕪊����đ��M����
                    IF TO_CHAR(inst_st, 'YYYYMMDD') < TO_CHAR(inst_end, 'YYYYMMDD') THEN
                        --�v��� 
                        WK_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(inst_st);
                        --���莞��
                        WK_ACT_RECV_WK_rec.ST_HM := CONVERT_DATE_STRING_HHMM(inst_st);
                        --�I������
                        WK_ACT_RECV_WK_rec.END_HM := '23:59';

                        INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);

                        --�v��� 
                        WK_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(inst_end);
                        --���莞��
                        WK_ACT_RECV_WK_rec.ST_HM := '00:00';
                        --�I������
                        WK_ACT_RECV_WK_rec.END_HM := CONVERT_DATE_STRING_HHMM(inst_end);

                        INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);
                    ELSE 
                        --�v��� 
                        WK_ACT_RECV_WK_rec.ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(inst_st);
                        --���莞��
                        WK_ACT_RECV_WK_rec.ST_HM := CONVERT_DATE_STRING_HHMM(inst_st);
                        --�I������
                        WK_ACT_RECV_WK_rec.END_HM := CONVERT_DATE_STRING_HHMM(inst_end);

                        INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);
                    END IF;

                    seq_data_no := WK_ACT_RECV_WK_rec.DATA_NO;
                END LOOP;
                CLOSE CURSOR_POP0020_K;

                 --8.2.2. �H���Ǘ�CD = �x�@���R�ɉ����ă��R�[�h���o�͂���@�@���x�@���R�ڍ�
                sSQLunpivot := '';
                sSQLunpivot := SQL_UNPIVOT_STOP_SEC(V1_rec.row_id);

                OPEN CURSOR_POP0020_L FOR sSQLunpivot;

                LOOP
                    FETCH CURSOR_POP0020_L INTO 
                       row_id_m_n
                        , column_name_m_n
                        , stop_sec_m_n;
                    EXIT WHEN CURSOR_POP0020_L%NOTFOUND;

                    -- Truong hop gia tri �x�@����_N_M bang null hoac bang 0 thi khong xu ly TODO
                    IF stop_sec_m_n IS NULL OR stop_sec_m_n = 0 THEN
                        CONTINUE;
                    END IF;

--                    DBMS_OUTPUT.put_line(column_name_m_n);
                    n_value := SUBSTR(column_name_m_n, 1, INSTR(column_name_m_n, '_')-1);
                    m_value := SUBSTR(column_name_m_n, INSTR(column_name_m_n, '_')+1);
                    sSQL := '';
                    sSQL := sSQL || ' SELECT ';
                    sSQL := sSQL || '   FILE_NAME ';
                    sSQL := sSQL || '   , T2.OPER_INST_NO ';
                    sSQL := sSQL || '   , M2.CHAR1 ';
                    sSQL := sSQL || '   , DECODE(WK1.SERVICE_SYSTEM, 1, ''A'', 2, ''B'', ''C'') ';
                    sSQL := sSQL || '   , SUBSTR(WK1.WK_USR_CD, 2, 4) ';
                    sSQL := sSQL || '   , M1.DPT_CD  ';
                    sSQL := sSQL || ' FROM ';
                    sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
                    sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
                    sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
                    sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
                    sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
                    sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
                    sSQL := sSQL || '   INNER JOIN MAM_USR_ACL M1  ';
                    sSQL := sSQL || '     ON M1.USR_CD = SUBSTR(WK1.WK_USR_CD, 2, 4)  ';
                    sSQL := sSQL || '     AND M1.ST_DT <= SYSDATE  ';
                    sSQL := sSQL || '     AND M1.END_DT >= SYSDATE  ';
                    sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M2  ';
                    sSQL := sSQL || '     ON M2.GP_GRP_CD = ''H0009''  ';
                    sSQL := sSQL || '     AND M2.KEY1 = CONCAT(''K'', ' || '''' || n_value || '''' || ')  ';
                    sSQL := sSQL || '     AND M2.KEY2 = ' || '''' || m_value || '''';
                    sSQL := sSQL || ' WHERE ';
                    sSQL := sSQL || '   WK1.INST_NO = ' || '''' || POP_PRCD_ACT_rec.INST_NO || '''';
                    sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
                    sSQL := sSQL || ' ORDER BY ';
                    sSQL := sSQL || '   T2.MFG_INST_NO ';
                    sSQL := sSQL || '   , T2.OPER_INST_NO ';
                    sSQL := sSQL || '   , M1.USR_CD ';

                    OPEN CURSOR_POP0020_L_SUB FOR sSQL;
                    WK_ACT_RECV_WK_rec := NULL;

                    LOOP
                        FETCH CURSOR_POP0020_L_SUB INTO 
                           file_name
                            , WK_ACT_RECV_WK_rec.OPER_INST_NO
                            , WK_ACT_RECV_WK_rec.WK_COST_CD
                            , WK_ACT_RECV_WK_rec.WK_DAY_CD
                            , WK_ACT_RECV_WK_rec.WK_USR_CD
                            , WK_ACT_RECV_WK_rec.WK_USR_DPT_CD;   
                        EXIT WHEN CURSOR_POP0020_L_SUB%NOTFOUND;

                        --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                        WK_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_ACT_RECV_FILE.nextval, 'FM0000000'));
                        --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                        WK_ACT_RECV_WK_rec.DATA_NO := seq_data_no;
                        --������CD = 'F1070'
                        WK_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1070';
                        --���M�����R�[�h�쐬���� = POP���Y���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                        WK_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                        --�f�[�^�X�V�敪 = '1'
                        WK_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                        --�H���w�}NO = T2.�H���w�}NO
                        --�H���Ǘ�CD = M2.������P
                        --�H�� = POP���Y���уt�@�C���̓����ڂ̒l 
                        WK_ACT_RECV_WK_rec.WK_COST := stop_sec_m_n;
                        --���f���� : �ҏW�Ȃ�
                        --�Ζ����CD = DECODE (WK1.�Ζ��̌n, 1, 'A', 2, 'B', 'C' )
                        --��Ǝ�CD = SUBSTR(WK1.��Ǝ҃R�[�h, 2, 4)
                        --��Ǝҕ���CD = M1.�啔��R�[�h
                        --�O���H������NO = T3.�O���H������NO**(3)�ɕۑ����ꂽ�Y���l���擾����B
                        WK_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := ext_oper_act_no;
                         --�o�͎�� = '4'
                        WK_ACT_RECV_WK_rec.OUTPUT_TYP := '4';

                        INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);

                    END LOOP;
                    CLOSE CURSOR_POP0020_L_SUB;

                END LOOP;
                CLOSE CURSOR_POP0020_L;

                --8.2.3. �H���Ǘ�CD = �l���A�������AM������d�ʁA�W���������A�ݒ�������A�J�n�������A�ŏI�������x�ɉ����ă��R�[�h���o�͂���B
                OPEN CURSOR_POP0020_M FOR SQL_MAN_HOUR_MANAGEMENT_OPTION(V1_rec.row_id);

                LOOP
                    FETCH CURSOR_POP0020_M INTO 
                        row_id_man_hour
                        , wk_cost
                        , val_num;
                    EXIT WHEN CURSOR_POP0020_M%NOTFOUND;

                    --POP0020_J.���ږ� bang null hoac bang 0 thi khong xu ly TODO
                    IF val_num IS NULL OR val_num = 0 THEN
                        CONTINUE;
                    END IF;

                    sSQL := '';
                    sSQL := sSQL || 'SELECT ';
                    sSQL := sSQL || '  FILE_NAME ';
                    sSQL := sSQL || '  , T2.OPER_INST_NO ';
                    sSQL := sSQL || '  , DECODE(WK1.SERVICE_SYSTEM, 1, ''A'', 2, ''B'', ''C'') ';
                    sSQL := sSQL || '  , SUBSTR(WK1.WK_USR_CD, 2, 4) ';
                    sSQL := sSQL || '  , M1.DPT_CD  ';
                    sSQL := sSQL || 'FROM ';
                    sSQL := sSQL || '  MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
                    sSQL := sSQL || '  INNER JOIN MSTA_POP_INST_ALL T1  ';
                    sSQL := sSQL || '    ON T1.MFG_INST_NO = WK1.INST_NO  ';
                    sSQL := sSQL || '  INNER JOIN MST_OPER_INST T2  ';
                    sSQL := sSQL || '    ON T2.MFG_INST_NO = WK1.INST_NO  ';
                    sSQL := sSQL || '    AND T2.OPER_CD = ''SX100''  ';
                    sSQL := sSQL || '  INNER JOIN MAM_USR_ACL M1  ';
                    sSQL := sSQL || '    ON M1.USR_CD = SUBSTR(WK1.WK_USR_CD, 2, 4)  ';
                    sSQL := sSQL || '    AND M1.ST_DT <= SYSDATE  ';
                    sSQL := sSQL || '    AND M1.END_DT >= SYSDATE  ';
                    sSQL := sSQL || 'WHERE ';
                    sSQL := sSQL || '   WK1.INST_NO = ' || '''' || POP_PRCD_ACT_rec.INST_NO || '''';
                    sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
                    sSQL := sSQL || 'ORDER BY ';
                    sSQL := sSQL || '  T2.MFG_INST_NO ';
                    sSQL := sSQL || '  , T2.OPER_INST_NO ';
                    sSQL := sSQL || '  , M1.USR_CD ';

                    OPEN CURSOR_POP0020_M_SUB FOR sSQL;
                    WK_ACT_RECV_WK_rec := NULL;

                    LOOP
                        FETCH CURSOR_POP0020_M_SUB INTO 
                           file_name
                            , WK_ACT_RECV_WK_rec.OPER_INST_NO
                            , WK_ACT_RECV_WK_rec.WK_DAY_CD
                            , WK_ACT_RECV_WK_rec.WK_USR_CD
                            , WK_ACT_RECV_WK_rec.WK_USR_DPT_CD;   
                        EXIT WHEN CURSOR_POP0020_M_SUB%NOTFOUND;

                        --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                        WK_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_ACT_RECV_FILE.nextval, 'FM0000000'));
                        --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                        WK_ACT_RECV_WK_rec.DATA_NO := seq_data_no;
                        --������CD = 'F1070'
                        WK_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1070';
                        --���M�����R�[�h�쐬���� = POP���Y���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                        WK_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                        --�f�[�^�X�V�敪 = '1'
                        WK_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                        --�H���w�}NO = T2.�H���w�}NO
                        --�H���Ǘ�CD = �Y���̏������R�[�h�̍H���Ǘ�CD
                        WK_ACT_RECV_WK_rec.WK_COST_CD := wk_cost;
                        --�H�� = POP���Y���уt�@�C���̓����ڂ̒l
                        WK_ACT_RECV_WK_rec.WK_COST := val_num;
                        --�Ζ����CD = DECODE (WK1.�Ζ��̌n, 1, 'A', 2, 'B', 'C' )
                        --��Ǝ�CD = SUBSTR(WK1.��Ǝ҃R�[�h, 2, 4)
                        --��Ǝҕ���CD = M1.�啔��R�[�h
                        --�O���H������NO = T3.�O���H������NO **(3)�ɕۑ����ꂽ�Y���l���擾����B
                        WK_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := ext_oper_act_no;
                         --�o�͎�� = '4'
                        WK_ACT_RECV_WK_rec.OUTPUT_TYP := '4';

                        INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);
                    END LOOP;
                    CLOSE CURSOR_POP0020_M_SUB;

                END LOOP;
                CLOSE CURSOR_POP0020_M;

                --8.2.4.�Z�Z�ݔ��R�[�h�A�Z�Z�ݔ��敪�ōH���Ǘ�CD�ɉ����郌�R�[�h���o�͂���
                OPEN CURSOR_POP0020_N FOR SQL_MAN_HOUR_MANAGEMENT_CODE(V1_rec.row_id);

                LOOP
                    FETCH CURSOR_POP0020_N INTO 
                        row_id_man_hour
                        , code
                        , val_str;
                    EXIT WHEN CURSOR_POP0020_N%NOTFOUND;

                    --POP0020_J.���ږ� bang null hoac bang '' thi khong xu ly TODO
                    IF val_str IS NULL OR TRIM(val_str) = '' THEN
                        CONTINUE;
                    END IF;

                    sSQL := '';
                    sSQL := sSQL || ' SELECT ';
                    sSQL := sSQL || '   FILE_NAME ';
                    sSQL := sSQL || '   , T2.OPER_INST_NO ';
                    sSQL := sSQL || '   , ''' || code || ''' || '':'' || M3.CHAR1 ';
                    sSQL := sSQL || '   , DECODE(WK1.SERVICE_SYSTEM, 1, ''A'', 2, ''B'', ''C'') ';
                    sSQL := sSQL || '   , SUBSTR(WK1.WK_USR_CD, 2, 4) ';
                    sSQL := sSQL || '   , M1.DPT_CD  ';
                    sSQL := sSQL || ' FROM ';
                    sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
                    sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
                    sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
                    sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
                    sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
                    sSQL := sSQL || '     AND T2.OPER_CD = ''SX100''  ';
                    sSQL := sSQL || '   INNER JOIN MAM_USR_ACL M1  ';
                    sSQL := sSQL || '     ON M1.USR_CD = SUBSTR(WK1.WK_USR_CD, 2, 4)  ';
                    sSQL := sSQL || '     AND M1.ST_DT <= SYSDATE  ';
                    sSQL := sSQL || '     AND M1.END_DT >= SYSDATE  ';
                    sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M2  ';
                    sSQL := sSQL || '     ON M2.GP_GRP_CD = ''H0010''  ';
                    sSQL := sSQL || '     AND M2.KEY1 = ' || '''' || TRIM(val_str) || '''';
                    sSQL := sSQL || '   INNER JOIN MAM_GP_ALL M3  ';
                    sSQL := sSQL || '     ON M3.GP_GRP_CD = ''H0011''  ';
                    sSQL := sSQL || '     AND M3.KEY1 = M2.CHAR2  ';
                    sSQL := sSQL || ' WHERE ';
                    sSQL := sSQL || '   WK1.INST_NO = ' || '''' || POP_PRCD_ACT_rec.INST_NO || '''';
                    sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
                    sSQL := sSQL || ' ORDER BY ';
                    sSQL := sSQL || '   T2.MFG_INST_NO ';
                    sSQL := sSQL || '   , T2.OPER_INST_NO ';
                    sSQL := sSQL || '   , M1.USR_CD ';

                    OPEN CURSOR_POP0020_N_SUB FOR sSQL;
                    WK_ACT_RECV_WK_rec := NULL;

                    LOOP
                        FETCH CURSOR_POP0020_N_SUB INTO 
                           file_name
                            , WK_ACT_RECV_WK_rec.OPER_INST_NO
                            , WK_ACT_RECV_WK_rec.INTR_RMRKS
                            , WK_ACT_RECV_WK_rec.WK_DAY_CD
                            , WK_ACT_RECV_WK_rec.WK_USR_CD
                            , WK_ACT_RECV_WK_rec.WK_USR_DPT_CD;   
                        EXIT WHEN CURSOR_POP0020_N_SUB%NOTFOUND;

                        -- �f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                         WK_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_ACT_RECV_FILE.nextval, 'FM0000000'));
                        --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                        WK_ACT_RECV_WK_rec.DATA_NO := seq_data_no;
                        --������CD = 'F1070'
                        WK_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1070';
                        --���M�����R�[�h�쐬���� = POP���Y���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                        WK_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                        --�f�[�^�X�V�敪 = '1'
                        WK_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                        --�H���w�}NO = T2.�H���w�}NO
                        --�H���Ǘ�CD = �Y���̏������R�[�h�̍H���Ǘ�CD
                        WK_ACT_RECV_WK_rec.WK_COST_CD := code;
                        --�������l = POP���Y���уt�@�C�� ||'"�F" || M3.������P�̈ꏏ���ڂ̒l
                        --�Ζ����CD = DECODE (WK1.�Ζ��̌n, 1, 'A', 2, 'B', 'C')
                        --��Ǝ�CD = SUBSTR(WK1.��Ǝ҃R�[�h, 2, 4)
                        --��Ǝҕ���CD = M1.�啔��R�[�h
                        --�O���H������NO =  **(3)�ɕۑ����ꂽ�Y���l���擾����B
                        WK_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := ext_oper_act_no;
                         --�o�͎�� = '4'
                        WK_ACT_RECV_WK_rec.OUTPUT_TYP := '4';

                        INSERT_WK_ACT_RECV_FILE_WK(WK_ACT_RECV_WK_rec);
                    END LOOP;
                    CLOSE CURSOR_POP0020_N_SUB;

                END LOOP;
                CLOSE CURSOR_POP0020_N;

            END LOOP;
            CLOSE CURSOR_POP0020_J;

            --9. �f�[�^���擾���A�H�����ю�M�t�@�C�� (���Y����)��}������
            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   FILE_NAME ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
            sSQL := sSQL || '   , WK1.INST_END ';
            sSQL := sSQL || '   , T1.TRD_UNIT_MFG_QTY  ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
            sSQL := sSQL || '   INNER JOIN MSTA_POP_INST_ALL T1  ';
            sSQL := sSQL || '     ON T1.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || '   INNER JOIN MST_OPER_INST T2  ';
            sSQL := sSQL || '     ON T2.MFG_INST_NO = WK1.INST_NO  ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   T2.OPER_CD = ''SX999''  ';
            sSQL := sSQL || '   AND WK1.PRCD_RECORD_STT = ''5''  ';
            sSQL := sSQL || '   AND WK1.ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            sSQL := sSQL || ' ORDER BY ';
            sSQL := sSQL || '   T2.MFG_INST_NO ';
            sSQL := sSQL || '   , T2.OPER_INST_NO ';
--            DBMS_OUTPUT.put_line(sSQL);
            OPEN CURSOR_POP0020_O FOR sSQL;
            OPER_ACT_RECV_WK_rec := NULL;

            LOOP
                FETCH CURSOR_POP0020_O INTO 
                   file_name
                    , OPER_ACT_RECV_WK_rec.OPER_INST_NO
                    , inst_end
                    , OPER_ACT_RECV_WK_rec.OPER_UNIT_QTY;   
                EXIT WHEN CURSOR_POP0020_O%NOTFOUND;

                --�f�[�^�sNO = �V�X�e�����t(yyyyMMdd) +�@Oracle�V�[�P���X(�V���j
                OPER_ACT_RECV_WK_rec.DATA_LNO := CONCAT(TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(MSSA_WK_OPER_ACT_RECV_FILE.nextval, 'FM0000000'));
                --�f�[�^NO = Oracle�V�[�P���X�i15���j�@�@��POP���тP���R�[�h���ɔ���
                OPER_ACT_RECV_WK_rec.DATA_NO := TO_CHAR(MSSA_WK_OPER_ACT_RECV_FILE_DATA_NO.nextval, 'FM000000000000000');
                --������CD = 'F1040'
                OPER_ACT_RECV_WK_rec.TRD_TYP_CD := 'F1040';
                --���M�����R�[�h�쐬���� = POP���Y���уt�@�C�� (WK1.FILE_NAME)�̃t�@�C���� (yyyy/MM/dd hh:mm:ss)
                OPER_ACT_RECV_WK_rec.DATA_MAKE_DT := CONVERT_DATE_STRING_YYYYMMDDHHMMSS(file_name);
                --�f�[�^�X�V�敪 = '1'
                OPER_ACT_RECV_WK_rec.DATA_CRUD_TYP := '1';
                --�H���w�}NO = T2.�H���w�}NO
                --������ѓ� = WK1.�I������ (yyyy/MM/dd)
                OPER_ACT_RECV_WK_rec.ST_ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(inst_end);
                --������ю��� = WK1.�I������ (HH:mm)
                OPER_ACT_RECV_WK_rec.ST_ACT_HM := CONVERT_DATE_STRING_HHMM(inst_end);
                --�I�����ѓ� = WK1.�I������ (yyyy/MM/dd)
                OPER_ACT_RECV_WK_rec.END_ACT_DT := CONVERT_DATE_STRING_YYYYMMDD(inst_end);
                --�I�����ю��� = WK1.�I������ (HH:mm)
                OPER_ACT_RECV_WK_rec.END_ACT_HM := CONVERT_DATE_STRING_HHMM(inst_end);
                --�H���P�ʎ��ѐ��� = T1.�݌v�Ǖi�o������
                --�O���H������NO = "KT" + {�f�[�^�sNO}
                 OPER_ACT_RECV_WK_rec.EXT_OPER_ACT_NO := 'KT' || YIELD_ACT_RECV_WK_rec.DATA_LNO;
                 --�o�͎�� = '4'
                OPER_ACT_RECV_WK_rec.OUTPUT_TYP := '4';

                INSERT_OPER_ACT_RECV_FILE_WK(OPER_ACT_RECV_WK_rec);

            END LOOP;
            CLOSE CURSOR_POP0020_O;

            sSQL := '';
            sSQL := sSQL || ' SELECT ';
            sSQL := sSQL || '   INST_NO, STK_LST_ISSUE ';
            sSQL := sSQL || ' FROM ';
            sSQL := sSQL || '   MSTA_POP_PRCD_ACT_FILE_WK_ALL ';
            sSQL := sSQL || ' WHERE ';
            sSQL := sSQL || '   ROWID LIKE ' || '''' || V1_rec.row_id || '''';
            
            OPEN CURSOR_POP0020_P FOR sSQL;
            POP_PRCD_ACT_rec := null;
            
            LOOP
                FETCH CURSOR_POP0020_P INTO 
                    POP_PRCD_ACT_rec.INST_NO
                    , POP_PRCD_ACT_rec.STK_LST_ISSUE;   
                EXIT WHEN CURSOR_POP0020_P%NOTFOUND;

                IF POP_PRCD_ACT_rec.STK_LST_ISSUE = '1' THEN
                    sSQLsub := '';
                    sSQLsub := sSQLsub || ' SELECT ';
                    sSQLsub := sSQLsub || '   T2.LOT_NO_PTN_CD ';
                    sSQLsub := sSQLsub || ' FROM ';
                    sSQLsub := sSQLsub || '   MST_MFG_INST M1  ';
                    sSQLsub := sSQLsub || '   INNER JOIN MST_ITM_MFG_INST M2  ';
                    sSQLsub := sSQLsub || '     ON M1.ITM_MFG_INST_NO = M2.ITM_MFG_INST_NO  ';
                    sSQLsub := sSQLsub || '   INNER JOIN MAM_ITM T2  ';
                    sSQLsub := sSQLsub || '     ON T2.ITM_CD = M2.ITM_CD  ';
                    sSQLsub := sSQLsub || '     AND T2.ITM_SUB1 = M2.ITM_SUB1  ';
                    sSQLsub := sSQLsub || '     AND T2.ITM_SUB2 = M2.ITM_SUB2  ';
                    sSQLsub := sSQLsub || '     AND T2.ITM_SUB3 = M2.ITM_SUB3  ';
                    sSQLsub := sSQLsub || ' WHERE ';
                    sSQLsub := sSQLsub || '   M1.MFG_INST_NO = ' || '''' || POP_PRCD_ACT_rec.INST_NO || '''';
                    
                    OPEN CURSOR_POP0020_P_SUB FOR sSQLsub;
                    LOOP
                        FETCH CURSOR_POP0020_P_SUB INTO 
                            no_ptn_cd;
                        EXIT WHEN CURSOR_POP0020_P_SUB%NOTFOUND;
                        IF no_ptn_cd IS NOT NULL THEN
                            lot_no_cd := GET_LOTNO(no_ptn_cd, I$CO_CD);
                            UPDATE MSTA_POP_INST_ALL 
                            SET LOT_NO = lot_no_cd
                            WHERE MFG_INST_NO = POP_PRCD_ACT_rec.INST_NO;
                            EXIT;
                        END IF;
                    END LOOP;
                    CLOSE CURSOR_POP0020_P_SUB;

                    EXIT;
                END IF;
            END LOOP;
            CLOSE CURSOR_POP0020_P;

        END LOOP;
    COMMIT;
    END POP0020;

/*
||-----------------------------------------------------------------------------
||�����v���V�[�W����`�L�q
||-----------------------------------------------------------------------------
*/
    PROCEDURE INSERT_POP_INST (
        POP_INST_rec        IN  MSTA_POP_INST_ALL%rowtype
    )
    IS
    BEGIN
        INSERT INTO MSTA_POP_INST_ALL (
            MFG_INST_NO
            , CO_CD
            , TRD_UNIT_MFG_QTY
            , LOT_NO
            , EXT_OPER_ACT_NO
        ) VALUES (
            POP_INST_rec.MFG_INST_NO
            , POP_INST_rec.CO_CD
            , POP_INST_rec.TRD_UNIT_MFG_QTY
            , POP_INST_rec.LOT_NO
            , POP_INST_rec.EXT_OPER_ACT_NO
        );
    END INSERT_POP_INST;

    PROCEDURE UPDATE_POP_INST_RESET_QTY (
        POP_INST_rec        IN  MSTA_POP_INST_ALL%rowtype
    )
    IS
    BEGIN
        UPDATE MSTA_POP_INST_ALL 
        SET EXT_OPER_ACT_NO = POP_INST_rec.EXT_OPER_ACT_NO
        WHERE  MFG_INST_NO = POP_INST_rec.MFG_INST_NO;
    END UPDATE_POP_INST_RESET_QTY;

    PROCEDURE UPDATE_POP_INST_QTY (
        POP_INST_rec        IN  MSTA_POP_INST_ALL%rowtype
    )
    IS
    BEGIN
        UPDATE MSTA_POP_INST_ALL 
        SET TRD_UNIT_MFG_QTY = TRD_UNIT_MFG_QTY + POP_INST_rec.TRD_UNIT_MFG_QTY
        WHERE  MFG_INST_NO = POP_INST_rec.MFG_INST_NO;
    END UPDATE_POP_INST_QTY;

    FUNCTION CONVERT_DATE_STRING_YYYYMMDDHHMMSS (
        date_value         IN DATE
    ) RETURN VARCHAR2 
    IS
    BEGIN
       RETURN TO_CHAR(date_value, 'yyyy/MM/dd hh24:mi:ss');
    END CONVERT_DATE_STRING_YYYYMMDDHHMMSS;

    FUNCTION CONVERT_DATE_STRING_YYYYMMDD (
        date_value         IN DATE
    ) RETURN VARCHAR2 
    IS
    BEGIN
        RETURN TO_CHAR(date_value, 'YYYY/MM/DD');
    END CONVERT_DATE_STRING_YYYYMMDD;

    FUNCTION CONVERT_DATE_STRING_HHMM (
        date_value         IN DATE
    ) RETURN VARCHAR2 
    IS
    BEGIN
        RETURN TO_CHAR(date_value, 'hh24:mi');
    END CONVERT_DATE_STRING_HHMM;

    PROCEDURE INSERT_YIELD_ACT_RECV_FILE_WK (
        YIELD_ACT_RECV_WK_rec        IN  MSTA_YIELD_ACT_RECV_FILE_WK_ALL%rowtype
    )
    IS
    BEGIN
        INSERT INTO MSTA_YIELD_ACT_RECV_FILE_WK_ALL (
            DATA_LNO
            , DATA_NO
            , TRD_TYP_CD
            , DATA_MAKE_DT
            , DATA_CRUD_TYP
            , YIELD_SCHD_NO
            , OPER_INST_NO
            , ITM_CD
            , TRD_UNIT_QTY
            , TRD_UNIT_CD
            , YIELD_TYP
            , YIELD_RSN_CD
            , LOT_NO
            , STRG_LOC_CD
            , STRG_STR_LN_CD
            , ACT_DT
            , ACT_HM
            , ABORT_FLG
            , EXT_OPER_ACT_NO
            , EXT_YIELD_ACT_NO
            , OUTPUT_TYP
        ) VALUES (
            YIELD_ACT_RECV_WK_rec.DATA_LNO
            , YIELD_ACT_RECV_WK_rec.DATA_NO
            , YIELD_ACT_RECV_WK_rec.TRD_TYP_CD
            , YIELD_ACT_RECV_WK_rec.DATA_MAKE_DT
            , YIELD_ACT_RECV_WK_rec.DATA_CRUD_TYP
            , YIELD_ACT_RECV_WK_rec.YIELD_SCHD_NO
            , YIELD_ACT_RECV_WK_rec.OPER_INST_NO
            , YIELD_ACT_RECV_WK_rec.ITM_CD
            , YIELD_ACT_RECV_WK_rec.TRD_UNIT_QTY
            , YIELD_ACT_RECV_WK_rec.TRD_UNIT_CD
            , YIELD_ACT_RECV_WK_rec.YIELD_TYP
            , YIELD_ACT_RECV_WK_rec.YIELD_RSN_CD
            , YIELD_ACT_RECV_WK_rec.LOT_NO
            , YIELD_ACT_RECV_WK_rec.STRG_LOC_CD
            , YIELD_ACT_RECV_WK_rec.STRG_STR_LN_CD
            , YIELD_ACT_RECV_WK_rec.ACT_DT
            , YIELD_ACT_RECV_WK_rec.ACT_HM
            , YIELD_ACT_RECV_WK_rec.ABORT_FLG
            , YIELD_ACT_RECV_WK_rec.EXT_OPER_ACT_NO
            , YIELD_ACT_RECV_WK_rec.EXT_YIELD_ACT_NO
            , YIELD_ACT_RECV_WK_rec.OUTPUT_TYP
        );
    END INSERT_YIELD_ACT_RECV_FILE_WK;

    PROCEDURE INSERT_OPER_ACT_RECV_FILE_WK (
          OPER_ACT_RECV_WK_rec         IN    MSTA_OPER_ACT_RECV_FILE_WK_ALL%rowtype
    )
    IS
    BEGIN
        INSERT INTO MSTA_OPER_ACT_RECV_FILE_WK_ALL (
            DATA_LNO
            , DATA_NO
            , TRD_TYP_CD
            , DATA_MAKE_DT
            , DATA_CRUD_TYP
            , OPER_INST_NO
            , ST_ACT_DT
            , ST_ACT_HM
            , END_ACT_DT
            , END_ACT_HM
            , OPER_UNIT_QTY
            , EXT_OPER_ACT_NO
            , OUTPUT_TYP
        ) VALUES (
            OPER_ACT_RECV_WK_rec.DATA_LNO
            , OPER_ACT_RECV_WK_rec.DATA_NO
            , OPER_ACT_RECV_WK_rec.TRD_TYP_CD
            , OPER_ACT_RECV_WK_rec.DATA_MAKE_DT
            , OPER_ACT_RECV_WK_rec.DATA_CRUD_TYP 
            , OPER_ACT_RECV_WK_rec.OPER_INST_NO
            , OPER_ACT_RECV_WK_rec.ST_ACT_DT
            , OPER_ACT_RECV_WK_rec.ST_ACT_HM
            , OPER_ACT_RECV_WK_rec.END_ACT_DT
            , OPER_ACT_RECV_WK_rec.END_ACT_HM
            , OPER_ACT_RECV_WK_rec.OPER_UNIT_QTY
            , OPER_ACT_RECV_WK_rec.EXT_OPER_ACT_NO
            , OPER_ACT_RECV_WK_rec.OUTPUT_TYP
        );
    END INSERT_OPER_ACT_RECV_FILE_WK;

    PROCEDURE INSERT_WK_ACT_RECV_FILE_WK (
          WK_ACT_RECV_WK_rec         IN    MSTA_WK_ACT_RECV_FILE_WK_ALL%rowtype
    )
    IS
    BEGIN
        INSERT INTO MSTA_WK_ACT_RECV_FILE_WK_ALL (
            DATA_LNO
            , DATA_NO
            , TRD_TYP_CD
            , DATA_MAKE_DT
            , DATA_CRUD_TYP
            , OPER_INST_NO
            , WK_COST_CD
            , WK_RSN_CD
            , WK_COST
            , INTR_RMRKS
            , ACT_DT
            , ST_HM
            , END_HM
            , BRK_PD
            , WK_COST_CALC_UPD_FLG
            , WK_DAY_CD
            , WK_USR_CD
            , WK_USR_DPT_CD
            , EXT_OPER_ACT_NO
            , EXT_YIELD_ACT_NO
            , OUTPUT_TYP
        ) VALUES (
            WK_ACT_RECV_WK_rec.DATA_LNO
            , WK_ACT_RECV_WK_rec.DATA_NO
            , WK_ACT_RECV_WK_rec.TRD_TYP_CD
            , WK_ACT_RECV_WK_rec.DATA_MAKE_DT
            , WK_ACT_RECV_WK_rec.DATA_CRUD_TYP
            , WK_ACT_RECV_WK_rec.OPER_INST_NO
            , WK_ACT_RECV_WK_rec.WK_COST_CD
            , WK_ACT_RECV_WK_rec.WK_RSN_CD
            , WK_ACT_RECV_WK_rec.WK_COST
            , WK_ACT_RECV_WK_rec.INTR_RMRKS
            , WK_ACT_RECV_WK_rec.ACT_DT
            , WK_ACT_RECV_WK_rec.ST_HM
            , WK_ACT_RECV_WK_rec.END_HM
            , WK_ACT_RECV_WK_rec.BRK_PD
            , WK_ACT_RECV_WK_rec.WK_COST_CALC_UPD_FLG
            , WK_ACT_RECV_WK_rec.WK_DAY_CD
            , WK_ACT_RECV_WK_rec.WK_USR_CD
            , WK_ACT_RECV_WK_rec.WK_USR_DPT_CD
            , WK_ACT_RECV_WK_rec.EXT_OPER_ACT_NO
            , WK_ACT_RECV_WK_rec.EXT_YIELD_ACT_NO
            , WK_ACT_RECV_WK_rec.OUTPUT_TYP
        );
    END INSERT_WK_ACT_RECV_FILE_WK;

    FUNCTION SQL_UNPIVOT_STOP_SEC(
        ROW_ID IN VARCHAR2
    ) RETURN VARCHAR2
    IS
        sSQLsub VARCHAR2(12048);
    BEGIN 
        sSQLsub := '';
        sSQLsub := sSQLsub || ' SELECT ';
        sSQLsub := sSQLsub || '   ROW_ID  ';
        sSQLsub := sSQLsub || '   , COLUMN_NAME  ';
        sSQLsub := sSQLsub || '   , STOP_SEC  ';
        sSQLsub := sSQLsub || ' FROM ';
        sSQLsub := sSQLsub || '   (  ';
        sSQLsub := sSQLsub || '     SELECT ';
        sSQLsub := sSQLsub || '       ROWID ROW_ID ';
        sSQLsub := sSQLsub || '       , WK1.*  ';
        sSQLsub := sSQLsub || '     FROM ';
        sSQLsub := sSQLsub || '       MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
        sSQLsub := sSQLsub || '     WHERE ';
        sSQLsub := sSQLsub || '         ROWID LIKE ' || '''' || ROW_ID || '''';
        sSQLsub := sSQLsub || '   ) UNPIVOT(  ';
        sSQLsub := sSQLsub || '     STOP_SEC FOR COLUMN_NAME IN (  ';
        sSQLsub := sSQLsub || '       STOP_SEC_1_1 AS ''1_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_2 AS ''1_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_3 AS ''1_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_4 AS ''1_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_5 AS ''1_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_6 AS ''1_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_7 AS ''1_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_8 AS ''1_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_9 AS ''1_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_1_10 AS ''1_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_1 AS ''2_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_2 AS ''2_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_3 AS ''2_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_4 AS ''2_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_5 AS ''2_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_6 AS ''2_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_7 AS ''2_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_8 AS ''2_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_9 AS ''2_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_2_10 AS ''2_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_1 AS ''3_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_2 AS ''3_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_3 AS ''3_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_4 AS ''3_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_5 AS ''3_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_6 AS ''3_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_7 AS ''3_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_8 AS ''3_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_9 AS ''3_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_3_10 AS ''3_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_1 AS ''4_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_2 AS ''4_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_3 AS ''4_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_4 AS ''4_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_5 AS ''4_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_6 AS ''4_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_7 AS ''4_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_8 AS ''4_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_9 AS ''4_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_4_10 AS ''4_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_1 AS ''5_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_2 AS ''5_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_3 AS ''5_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_4 AS ''5_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_5 AS ''5_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_6 AS ''5_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_7 AS ''5_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_8 AS ''5_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_9 AS ''5_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_5_10 AS ''5_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_1 AS ''6_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_2 AS ''6_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_3 AS ''6_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_4 AS ''6_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_5 AS ''6_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_6 AS ''6_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_7 AS ''6_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_8 AS ''6_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_9 AS ''6_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_6_10 AS ''6_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_1 AS ''7_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_2 AS ''7_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_3 AS ''7_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_4 AS ''7_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_5 AS ''7_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_6 AS ''7_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_7 AS ''7_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_8 AS ''7_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_9 AS ''7_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_7_10 AS ''7_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_1 AS ''8_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_2 AS ''8_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_3 AS ''8_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_4 AS ''8_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_5 AS ''8_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_6 AS ''8_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_7 AS ''8_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_8 AS ''8_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_9 AS ''8_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_8_10 AS ''8_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_1 AS ''9_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_2 AS ''9_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_3 AS ''9_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_4 AS ''9_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_5 AS ''9_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_6 AS ''9_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_7 AS ''9_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_8 AS ''9_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_9 AS ''9_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_9_10 AS ''9_10'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_1 AS ''10_1'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_2 AS ''10_2'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_3 AS ''10_3'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_4 AS ''10_4'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_5 AS ''10_5'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_6 AS ''10_6'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_7 AS ''10_7'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_8 AS ''10_8'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_9 AS ''10_9'' ';
        sSQLsub := sSQLsub || '       , STOP_SEC_10_10 AS ''10_10'' ';
        sSQLsub := sSQLsub || '     ) ';
        sSQLsub := sSQLsub || '   ) ';

        RETURN sSQLsub;
    END SQL_UNPIVOT_STOP_SEC;

    FUNCTION SQL_SUM_STOP_SEC(
        ROW_ID IN VARCHAR2
    ) RETURN VARCHAR2
    IS
        sSQLsum VARCHAR2(12048);
    BEGIN 
        sSQLsum := '';
        sSQLsum := sSQLsum || ' SELECT SUM(STOP_SEC) FROM ( ';
        sSQLsum := sSQLsum || SQL_UNPIVOT_STOP_SEC(ROW_ID);
        sSQLsum := sSQLsum || ') T';

        RETURN sSQLsum;
    END SQL_SUM_STOP_SEC;

    FUNCTION SQL_MAN_HOUR_MANAGEMENT_OPTION(
        ROW_ID IN VARCHAR2
    ) RETURN VARCHAR2
    IS
        sSQLsub VARCHAR2(2048);
    BEGIN 
        sSQLsub := '';
        sSQLsub := sSQLsub || ' SELECT ';
        sSQLsub := sSQLsub || '   ROW_ID ';
        sSQLsub := sSQLsub || '   , WK_COST ';
        sSQLsub := sSQLsub || '   , VAL  ';
        sSQLsub := sSQLsub || ' FROM ';
        sSQLsub := sSQLsub || '   (  ';
        sSQLsub := sSQLsub || '     SELECT ';
        sSQLsub := sSQLsub || '       ROWID ROW_ID ';
        sSQLsub := sSQLsub || '       , DECODE(ACTUAL_NUM , 0 , 0  ';
        sSQLsub := sSQLsub || ' 	  	, DECODE( MEASURED_L_DIMENSION , 0 , 0 , MEASURED_WEIGHT / ACTUAL_NUM / MEASURED_L_DIMENSION) ';
        sSQLsub := sSQLsub || '       ) WEIGHT_PER_M ';
        sSQLsub := sSQLsub || '       , WK1.*  ';
        sSQLsub := sSQLsub || '     FROM ';
        sSQLsub := sSQLsub || '       MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
        sSQLsub := sSQLsub || '     WHERE ';
        sSQLsub := sSQLsub || '       ROWID LIKE ' || '''' || ROW_ID || '''';
        sSQLsub := sSQLsub || '   ) UNPIVOT(  ';
        sSQLsub := sSQLsub || '     VAL FOR WK_COST IN (  ';
        sSQLsub := sSQLsub || '       PERSON_NUM AS ''AX001'' ';                --�l��
        sSQLsub := sSQLsub || '       , SOLID_SPEED AS ''AS001'' ';             --������
        sSQLsub := sSQLsub || '       , STD_RESIN_TEMPERATURE AS ''AM001'' ';   --M������d�� = �����d�� �� �����{�� �� ����L��
        sSQLsub := sSQLsub || '       , WEIGHT_PER_M AS ''AJ001'' ';            --�W��������
        sSQLsub := sSQLsub || '       , SET_RESIN_TEMPERATURE AS ''AJ002'' ';   --�ݒ������
        sSQLsub := sSQLsub || '       , RESIN_TEMPERATURE_ST AS ''AJ003'' ';    --�J�n������
        sSQLsub := sSQLsub || '       , RESIN_TEMPERATURE_ET AS ''AJ004'' ';    --�ŏI�������x
        sSQLsub := sSQLsub || '     ) ';
        sSQLsub := sSQLsub || '   ) ';

        RETURN sSQLsub;
    END SQL_MAN_HOUR_MANAGEMENT_OPTION;

    FUNCTION SQL_MAN_HOUR_MANAGEMENT_CODE(
        ROW_ID IN VARCHAR2
    ) RETURN VARCHAR2
    IS
        sSQLsub VARCHAR2(2048);
    BEGIN 
        sSQLsub := '';
        sSQLsub := sSQLsub || ' SELECT ';
        sSQLsub := sSQLsub || '  ROW_ID ';
        sSQLsub := sSQLsub || '  , CODE ';
        sSQLsub := sSQLsub || '  , VAL  ';
        sSQLsub := sSQLsub || 'FROM ';
        sSQLsub := sSQLsub || '  (  ';
        sSQLsub := sSQLsub || '    SELECT ';
        sSQLsub := sSQLsub || '      ROWID ROW_ID ';
        sSQLsub := sSQLsub || '      , WK1.*  ';
        sSQLsub := sSQLsub || '    FROM ';
        sSQLsub := sSQLsub || '      MSTA_POP_PRCD_ACT_FILE_WK_ALL WK1  ';
        sSQLsub := sSQLsub || '    WHERE ';
        sSQLsub := sSQLsub || '       ROWID LIKE ' || '''' || ROW_ID || '''';
        sSQLsub := sSQLsub || '  ) UNPIVOT(  ';
        sSQLsub := sSQLsub || '    VAL FOR CODE IN (  ';
        sSQLsub := sSQLsub || '      EQUIPMENT1 AS ''OS001'' ';                 --���o�@�ݔ��R�[�h - ���o�@�ݔ��敪
        sSQLsub := sSQLsub || '      , EQUIPMENT2 AS ''OS002'' ';               --����@�ݔ��R�[�h - ����@�ݔ��敪
        sSQLsub := sSQLsub || '      , EQUIPMENT3 AS ''OS003'' ';               --��F�@A�ݔ��R�[�h - ��F�@A�ݔ��敪
        sSQLsub := sSQLsub || '      , EQUIPMENT4 AS ''OS004'' ';               --��F�@B�ݔ��R�[�h - ��F�@B�ݔ��敪
        sSQLsub := sSQLsub || '    ) ';
        sSQLsub := sSQLsub || '  ) ';
        RETURN sSQLsub;
    END SQL_MAN_HOUR_MANAGEMENT_CODE;

    FUNCTION GET_LOTNO(
        NUM_PTN_CD IN VARCHAR2,
        CO_CD IN VARCHAR2
    ) RETURN VARCHAR2
    IS
        result_val VARCHAR2(2048);
    BEGIN 
        result_val := '';
        INSERT INTO MAW_NUM_ARG (
            NUM_PTN_CD
            , PEG_NO
            , LOC_CD
            , BP_CD
            , WG_CD
            , SITE_CD
            , DT
            , CHD_LOT_NO
            , SNO1
            , SNO2
            , SNO3
            , SNO4
            , CO_CD
        ) VALUES (
--            'FVK'
            NUM_PTN_CD
            , 1
            , ''
            , ''
            , ''
            , ''
            , ''
            , ''
            , ''
            , ''
            , ''
            , ''
            , CO_CD
        );

        MAPA_NUM.P_SET_BY_PTN('LOT');

        SELECT NEW_NO  INTO result_val
        FROM MAW_NUM_ARG
        WHERE ROWNUM = 1;
        RETURN result_val;
    END GET_LOTNO;

END PKG_POP0020;